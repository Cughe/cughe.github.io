(function(){
  "use strict";
  var DATA = window.__SXXM_DATA__ || { articles: [] };
  var state = { q: "", sort: "desc", page: 1, pageSize: 10 };
  function $(id){ return document.getElementById(id); }
  var els = { search: $("searchInput"), sort: $("sortToggle"), pageSize: $("pageSizeSelect"),
    tbody: $("tocBody"), empty: $("emptyState"), emptyText: $("emptyText"),
    pagination: $("pagination"), total: $("totalCount"), filterInfo: $("filterInfo") };
  function esc(s){ return String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;"); }
  function dateText(a){
    if(!a) return "";
    if(a.dateDisplay==="unknown") return "日期未知";
    if(a.dateDisplay==="custom") return (a.dateCustom||"").trim() || "日期未知";
    if(!a.date) return "日期未知";
    var p=String(a.date).split("-"), s=p[0]+"年";
    if(p[1]) s+=parseInt(p[1],10)+"月";
    if(p[2]) s+=parseInt(p[2],10)+"日";
    return (a.dateApprox?"约":"")+s;
  }
  function filterAndSort(){
    var list=(DATA.articles||[]).slice();
    var q=state.q.trim().toLowerCase();
    if(q){ list=list.filter(function(a){
      return (a.title||"").toLowerCase().indexOf(q)>=0 || (a.body||"").toLowerCase().indexOf(q)>=0 || (a.author||"").toLowerCase().indexOf(q)>=0;
    }); }
    var known=[],unknown=[];
    list.forEach(function(a){ (a.date?known:unknown).push(a); });
    known.sort(function(x,y){
      var c=x.date<y.date?-1:(x.date>y.date?1:0);
      if(c!==0) return state.sort==="asc"?c:-c;
      return (x.createdAt||"")<(y.createdAt||"")?-1:1;
    });
    unknown.sort(function(x,y){ return (x.createdAt||"")<(y.createdAt||"")?-1:1; });
    return known.concat(unknown);
  }
  function pageNumbers(cur,total){
    var nums=[];
    for(var i=1;i<=total;i++){
      if(i===1||i===total||Math.abs(i-cur)<=2){ nums.push(i); }
      else if(nums[nums.length-1]!=="…"){ nums.push("…"); }
    }
    return nums;
  }
  function renderPagination(totalPages,totalItems){
    els.pagination.innerHTML="";
    if(totalItems===0) return;
    var prev=document.createElement("button");
    prev.className="page-btn";prev.textContent="‹ 上一页";prev.disabled=state.page<=1;
    prev.addEventListener("click",function(){ state.page--; render(); });
    els.pagination.appendChild(prev);
    pageNumbers(state.page,totalPages).forEach(function(p){
      var b=document.createElement("button");
      if(p==="…"){ b.className="page-btn ellipsis"; b.textContent="…"; }
      else {
        b.className="page-btn"+(p===state.page?" current":"");
        b.textContent=String(p);
        b.addEventListener("click",function(){ state.page=p; render(); });
      }
      els.pagination.appendChild(b);
    });
    var next=document.createElement("button");
    next.className="page-btn";next.textContent="下一页 ›";next.disabled=state.page>=totalPages;
    next.addEventListener("click",function(){ state.page++; render(); });
    els.pagination.appendChild(next);
    var info=document.createElement("span");
    info.className="page-info";info.textContent="第 "+state.page+" / "+totalPages+" 页";
    els.pagination.appendChild(info);
  }
  function render(){
    var list=filterAndSort();
    var totalPages=Math.max(1,Math.ceil(list.length/state.pageSize));
    if(state.page>totalPages) state.page=totalPages;
    if(state.page<1) state.page=1;
    var start=(state.page-1)*state.pageSize;
    var pageItems=list.slice(start,start+state.pageSize);
    els.tbody.innerHTML="";
    pageItems.forEach(function(a,i){
      var tr=document.createElement("tr");
      tr.className="toc-row";
      tr.innerHTML="<td class=\"col-index\">"+(start+i+1)+"</td>"+
        "<td class=\"col-title\"><a class=\"article-link\" href=\""+esc(a.file)+"\">"+esc(a.title)+"</a></td>"+
        "<td class=\"col-date\">"+esc(dateText(a))+"</td>"+
        "<td class=\"col-author\">"+esc(a.author||"佚名")+"</td>";
      tr.addEventListener("click",function(e){
        if(e.target.closest("a")) return;
        location.href=a.file;
      });
      els.tbody.appendChild(tr);
    });
    els.empty.hidden=list.length!==0;
    if(list.length===0){
      els.emptyText.textContent=state.q?"没有找到包含「"+state.q+"」的文章，换个关键词试试。":"这个集子还是空的。";
    }
    els.total.innerHTML="共 <strong>"+(DATA.articles||[]).length+"</strong> 篇";
    els.filterInfo.textContent=state.q?("搜索「"+state.q+"」："+list.length+" 条结果"):"";
    renderPagination(totalPages,list.length);
    els.sort.textContent=state.sort==="desc"?"时间倒序 ↓（新 → 旧）":"时间正序 ↑（旧 → 新）";
  }
  var debounce;
  els.search.addEventListener("input",function(){
    clearTimeout(debounce);
    debounce=setTimeout(function(){ state.q=els.search.value; state.page=1; render(); },150);
  });
  els.sort.addEventListener("click",function(){
    state.sort=state.sort==="desc"?"asc":"desc"; state.page=1; render();
  });
  els.pageSize.addEventListener("change",function(){
    state.pageSize=parseInt(els.pageSize.value,10)||10; state.page=1; render();
  });
  render();
})();